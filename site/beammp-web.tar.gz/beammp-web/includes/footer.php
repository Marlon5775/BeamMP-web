<footer>
    <p>&copy; 2024 Serveur Zyphro | <?= t('footer_rights') ?></p>
    <p>
        <a href="../pages/politique.html" style="color: white; text-decoration: underline;">
            <?= t('footer_legal') ?>
        </a>
    </p>
</footer>
