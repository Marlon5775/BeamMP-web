<?php
require_once __DIR__ . '/vendor/autoload.php';
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$webhookUrl = $_ENV['DISCORD_WEBHOOK_SERVER_RESTART'];

$data = [
    "content" => "✅ Test de webhook depuis PHP"
];

$options = [
    'http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/json\r\n",
        'content' => json_encode($data)
    ]
];

$context = stream_context_create($options);
$response = file_get_contents($webhookUrl, false, $context);

if ($response === false) {
    echo "❌ Échec de l'envoi";
} else {
    echo "✅ Message envoyé avec succès !";
}
